class Text
  def initialize(text) @text = text end
  def write(info, out) out.print @text end
end

class Res
  def initialize(name) @name = name end
  def write(info, out) out.print info[@name] end
end

class Template
  TAG = /(<%=\s[a-zA-Z_][a-zA-Z_0-9]*\s%>)/
  def initialize(source)
    @ress = Array.new
    source.split(TAG).each {|token|
      m = token.match(TAG)
      @ress << 
        if m != nil then
          name = m[0].to_s; Res.new(name[3..(name.length-3)].strip)
        else Text.new(token) end
    }
  end
  def write(info, out) @ress.each {|res| res.write(info, out)} end
end

template = Template.new(
'Subject: Mail Magazine No.<%= no %>

Mail magazine no.<%= no %>
Hello, <%= name %> san!
')

template.write({"name" => "NISHIMOTO Keisuke", "no" => 1234}, STDOUT)

