val f: (Int, Int)=>Int = (a, b) => a + b

println(f(1, 2))
