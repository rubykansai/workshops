implicit def int2string(n: Int): String = "" + n

def add(a: String, b: String): String = a + b

println(add(1, 2))
