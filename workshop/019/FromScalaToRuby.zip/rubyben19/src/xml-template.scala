import scala.collection.immutable._
import scala.xml._

val template =
<article>Subject: Mail magazine no.<res name="no"/>

Mail magazine no.<res name="no"/>.
Hello, <res name="name"/> san
</article>

val table = Map(("no", "1234"), ("name", "NISHIMOTO Keisuke"))

for(node <- template.child) {
  node match {
    case text: Text => print(text.text)
    case elem: Elem =>
      if(elem.label == "res") print(table(elem.attribute("name").get.text))
  }
}
