import java.io.{Reader, FileReader, IOException}
import scala.collection.mutable.ArrayBuffer

var reader: Reader = null
try {
  reader = new FileReader("sample.txt")
  val buf: Array[Char] = new Array[Char](1024)
  var textBuf = new ArrayBuffer[Char]()
  var len: Int = 0
  do {
    len = reader.read(buf)
    if(len > 0) textBuf ++= (buf, 0, len)
  } while(len > 0)
  val text = new String(textBuf.toArray).trim
  println("Text is \"" + text + "\"")
  if(!text.equals("Hello, world!")) throw new IOException("Error")
} catch {
  case e: IOException => println(e)
} finally {
  reader.close
}

