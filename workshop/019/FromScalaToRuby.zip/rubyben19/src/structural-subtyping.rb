class Foo
  def name
    "Foo"
  end
end

class Boo
  def name
    "Boo"
  end
end

ma = [Foo.new, Boo.new]

ma.each {|m| puts m.name}
