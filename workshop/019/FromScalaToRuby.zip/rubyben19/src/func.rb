f = proc {|a, b| a + b}

puts f.call(1, 2)
