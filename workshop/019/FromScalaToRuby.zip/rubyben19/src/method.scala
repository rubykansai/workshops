def log(message: String): Unit = {
  println(message)
}
/*
def log(message: String) {
  println(message)
}
*/

def add(a: Int, b: Int): Int = {
  return a + b
}

log("Hello!")
println(add(1234, 5678))

