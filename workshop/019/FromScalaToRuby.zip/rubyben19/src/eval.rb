article_template =
'Subject: Mail Magazine No.#{info[:no]}

Mail magazine no.#{info[:no]}
Hello, #{info[:name]} san!
'

info = {
  :name => "NISHIMOTO Keisuke",
  :no => 1234
}
puts eval("\"#{article_template}\"")
