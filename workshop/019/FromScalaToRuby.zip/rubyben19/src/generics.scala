println("val Array[String]:")

val stringArray: Array[String] =
  Array[String]("Foo", "Boo", "Bar")
for(str <- stringArray) printf(str + " "); println()


println("foreach[A](Collection[A], (A) => Unit):")

def foreach[A](array: Collection[A], f: (A) => Unit) =
  for(value <- array) f(value)
foreach[String](
  Array("Foo", "Boo", "Bar"), (str) => print(str + " "))
println()


println("class Memo[A]:")

class Memo[A](var value: A)
val memo = new Memo[String]("Hello!")
println(memo.value)
