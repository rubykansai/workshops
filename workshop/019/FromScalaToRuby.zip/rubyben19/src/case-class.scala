abstract class Status
case class Start(message: String) extends Status
case class End(message: String) extends Status

val status: Status = new Start("Hello!")
status match {
  case Start(message) => println("start: " + message)
  case End(message) => println("end: " + message)
}
