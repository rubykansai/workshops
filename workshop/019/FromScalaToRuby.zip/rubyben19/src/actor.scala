import scala.actors.Actor
import scala.actors.Actor._

object Sample extends Application {

  case object E

  var a1: Actor = null
  var a2: Actor = null

  a1 = actor {
    react {
      case E => {println("a1 start"); a2 ! E; println("a1 end")}
    }
  }

  a2 = actor {
    react {
      case E => {println("a2 start"); a1 ! E; println("a2 end")}
    }
  }

  a1 ! E
}

