def prints(values: Collection[Int]) {
 for(value <- values) print(value + " ")
 println()
}

// for, foreach

println("for:")

for (i <- 0 until 10) printf(i + " ")
println()

println("foreach:")

(0 until 10).foreach((i) => printf(i + " "))
println()

// for(map), map

println("for(map):")

val pows1 = for(i <- 1 to 10) yield i * i
prints(pows1)

println("map:")

val pows2 = (1 to 10).map((i) => i * i)
prints(pows2)

// for(filter), filter

println("for(filter):")

val evens1 = for(i <- 1 to 10; if i % 2 == 0) yield i
prints(evens1)

println("filter:")

val evens2 = (1 to 10).filter((i) => i % 2 == 0)
prints(evens2)
