def type_check(typ)
  case typ
  when String
    puts "String"
  when Numeric
    puts "Numeric"
  when Symbol
    puts "Symbol"
  else
    puts "etc..."
  end
end

type_check("Hello")
type_check(:Hello)
type_check(1234)

