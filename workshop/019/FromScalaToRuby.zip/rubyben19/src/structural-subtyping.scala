class Foo {
  def name = "Foo"
}

class Boo {
  def name = "Boo"
}

val ma = Array[{def name: String}](new Foo, new Boo)

for(m <- ma) println(m.name)
