def prints(values)
  for value in values
    print value, " "
  end
  puts ""
end

# for, foreach

puts "for:"

for i in 0..(10-1)
  print i, " "
end
puts

puts "foreach:"

(0..(10-1)).each {|i| print i, " "}
puts

# for(map), map

puts "map:"

pows2 = (1..10).map {|i| i * i}
prints(pows2)

# for(filter), filter

puts "filter:"

evens2 = (1..10).find_all {|i| i % 2 == 0}
prints(evens2)
