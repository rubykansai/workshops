f1 = f2 = nil

f1 = Fiber.new {
  puts "f1 start"; f2.yield; puts "f1 end"
}

f2 = Fiber.new {
  puts "f2 start"; f1.yield; puts "f2 end"
}

f1.yield
