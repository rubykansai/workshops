#encoding: utf-8
require 'miyako'

include Miyako

Se = InitiativeScenarioEngine
Set = InitiativeScenarioEngineTemplate

class SampleTemp
  include Set
  
  def render_inner(engine)
    engine.render_all
  end
end

class MainScene
  include SimpleStory::Scene
  
  def load_image(str)
    [
      Sprite.new(:file=>"image/#{str}_rev.png", :type=>:as),
      Sprite.new(:file=>"image/#{str}.png", :type=>:as)
    ]
  end
  
  def load_command(str)
    Se::Command.new(
      *load_image(str),
      nil,
      true,
      lambda{ true },
      str
    )
  end
  
  def init
    @janken = {"guu" => 0,
               "choki" => 1,
               "paa" => 2}
               
    @commands = @janken.keys.map{|key|
      load_command(key)
    }
    
    @sc = Sprite.new(:file=>"cursor/select_cursor.png", :type=>:ac)
    @wc = Sprite.new(:file=>"cursor/wait_cursor.png", :type=>:ac)
    @font = Font.sans_serif.tap{|font| font.size=24}
    
    @box = TextBox.new(
            :size => [20, 8],
            :font => @font,
            :sc => @sc,
            :wc => @wc).center!.bottom!{|base| 5.percent(base)}
    @box.show
    
    @se = Se.new
    @se.setup(@box){|box|
      select_textbox(box)
    }
    
    @se.bgs[:bg] = Sprite.new(:file=>"image/bg.jpg",:type=>:as).centering!
    @se.visibles[:misasagi] = Sprite.new(:file=>"image/misasagi2.png",:type=>:ac).center!.bottom!
    
    @base = SampleTemp.new
  end
    
  def execute
    @se.start_plot(@base, nil, @commands, @janken){|com, janken|
      @res = [0, 0, 0]
      
      text "じゃんけん、しよ。"
      cr
      clear
      loop do
        text "じゃーんけーん・・・"
        cr
        command com
        break if select_result == Se::Canceled
        my = select_result
        you = janken.keys.sample
        @res[janken[you] - janken[my]] += 1
        text "わたし: #{you}"
        cr
        text "あなた: #{my}"
        cr
        text "win: #{@res[1]} lose: #{@res[2]}"
        cr
        pause
        clear
      end
    }
  
    return nil
  end
end

st = SimpleStory.new
st.run(MainScene)
