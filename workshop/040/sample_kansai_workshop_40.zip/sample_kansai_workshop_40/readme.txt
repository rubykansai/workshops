*******************************************************************************
【   作者名   】　サイロス誠
【  ソフト名  】　Miyako v2.1サンプル(ノベルゲーム風じゃんけん)
【 バージョン 】　1.0
【   作成日   】　2010/01/31
【    種別    】　フリーウェア
【  開発言語  】　Ruby 1.9.1-p0
【 ランタイム 】　Miyako v2.1.7-
【  対応機種  】　Windows 2000/XP/Vista、Linux
【   再配布   】　修正BSDライセンスによる
【    転載    】　修正BSDライセンスによる
【ホームページ】　http://www.twin.ne.jp/~cyross/Miyako/
【   連絡先   】　cyross@po.twin.ne.jp
*******************************************************************************

・概要

　このプログラムは、Miyako v2.1.8以降に対応する、Miyakoサンプルプログラムです。
　InitiativeScenarioEngine(ゲームループが本体に組み込まれているシナリオエンジン)のサンプルです。
  2010/1/30に行われた、第40回Ruby/Rails勉強会@関西で、10分でゲームを作っってみました(実際は15分かかった)。
  Miykaoのノベルゲームシステム(InitiativeScenarioEngine)を使ってじゃんけんゲームを作りました。
  今回は、そのときのスクリプトと、修正バージョンを配布いたします。
  画像は、前にシナリオエンジンのサンプルに使った画像の使い回しと、会場で慌てて作成(す、すみません!)した
  手の写真(とそれを反転させた物)です。
  
・ファイルの構成

  本アーカイブには、以下のファイルが含まれています
  
  ・readme.txt(本ファイル)
  ・main.rb(main.rbに、修正・コメントを施したバージョン)
  ・main_org.rb(実際に勉強会で作成したときのmain.rb)
　・cursor(カーソル画像があるフォルダ)
　・image(画像フォルダ) 

・Miyakoについて

　Miyakoに関しては、以下のURLを参考にしてください。
  (メインサイト)
  http://www.twin.ne.jp/~cyross/Miyako/

　Miyako(Ruby、Ruby/SDL含む)のインストールに関しましては、
上記URLを辿って得られるアーカイブされたMiyakoライブラリを
展開すると、readme.txtが得られますので、そちらをご参照下さい。

　本サンプルでは、MiyakoがWindows上で動作することを前提にしています。
（インストールしたRuby実行環境がActiveRubyであることも前提に
　しています）

・起動方法

　エクスプローラーを開き、本サンプルのフォルダ内で、「main.rb」を
ダブルクリックします。
　コマンドライン上で動かす場合は、本サンプルのディレクトリに
移動して、以下のコマンドを入力します。

　ruby main.rb

・免責事項

　本サンプルは無保証です。もし本サンプルを使用することによる不具合・トラブル
が起こったとしても、いかなるトラブルに対する責任を負わないことをご了承下さい。

　本サンプルは、修正BSDライセンスに基づいた転載・再配布を許可します。

・謝辞

　本サンプルの背景に、以下の背景素材を使用させていただきました。ありがとうございます。

　風景素材写真集「materials」 サークルAL-bioN

・修正履歴

　(1.0)
　・ファーストリリース

・BSDライセンス文

Copyright (c) 2010, Cyross Makoto

All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

・Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
・Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
・Neither the name of the Cyross Makoto nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
