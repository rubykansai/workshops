#encoding: utf-8

# ノベルゲームシステムでじゃんけんゲーム(修正版)
# @第40回Ruby/Rails勉強会@関西
# 2010.01.31 Cyross Makoto

# ノベルゲームのコマンド選択を利用した

# おまじない
require 'miyako'

# これもおまじない
include Miyako

# シナリオエンジンクラスは、名前が非常に長いため、短い時間でのライブコーディングに向かない
# そのため、略称を定義している
Se = InitiativeScenarioEngine
SeTmp = InitiativeScenarioEngineTemplate

# InitiativeScenarioEngineでは、メインループはシナリオエンジン内にあるため、
# 他にさせたい処理をテンプレートメソッドを定義したオブジェクトを渡すことでおこなっている
# 今回は、シナリオエンジンに登録されている全ての画像を描画するコードのみ追加した＃
class SampleTemp
  include SeTmp
  
  # 描画の追加処理を定義
  # engineは実行しているシナリオエンジン本体
  def render_inner(engine)
    # 背景→前景1→テキストボックス→前景2の順に描画
    engine.render_all
  end
end

# メインシーン
# シーンは、シーン管理の一つの単位。
# 本来は、複数のシーンが、それぞれクラスとして存在しているが、
# 今回は用意するシーンは一つだけでよいので、他のクラスは作成していない
# ちなみに、シーンを移動する際は、executeメソッドの返却値に
# クラス名(厳密に言うとclassクラスのオブジェクト)を渡すだけでよい
class MainScene
  # Sceneモジュールをmixinすることで、シーンの骨格ができあがる
  include SimpleStory::Scene
  
  # 引数の文字列から、2つのファイルを読みこみ、スプライトの配列を生成する
  def load_image(str)
    [
      Sprite.new(:file=>"image/#{str}_rev.png", :type=>:as),
      Sprite.new(:file=>"image/#{str}.png", :type=>:as)
    ]
  end
  
  # InitiativeScenarioEngine::Command構造体を生成する
  # 実際の引数は6個だが、Ruby1.9の配列展開を利用しているため、
  # 5個に見えるところに注意!
  # それぞれの引数は、
  # 1,2) 非選択時に描画するスプライト、選択時に描画するスプライト
  # 3) 選択不可時に描画するスプライト(省略時はnilを渡す)
  # 4) 選択可・不可のフラグ
  # 5) 表示条件を返すブロック(trueを返すときは表示)
  # 6) 選択したときに返す結果(select_resultメソッドの値になる)
  def load_command(str)
    Se::Command.new(
      *load_image(str),
      nil,
      true,
      lambda{ true },
      str
    )
  end
  
  # シーンの情報初期化メソッド
  def init
    # じゃんけんの手と数値とを関連づけたハッシュ
    @janken = {"guu" => 0,
               "choki" => 1,
               "paa" => 2}
               
    # じゃんけんの手を選択するときに表示させるコマンド群
    @commands = @janken.keys.map{|key|
      load_command(key)
    }
    
    # コマンド選択時にコマンドを指し示すカーソルを示すスプライト
    @sc = Sprite.new(:file=>"cursor/select_cursor.png", :type=>:ac)
    # キー入力待ちカーソルを示すスプライト
    @wc = Sprite.new(:file=>"cursor/wait_cursor.png", :type=>:ac)
    # テキストボックスに描画するフォント
    # マルチプラットフォーム対応にするため、ここでは、ファイル名を指定しない
    @font = Font.sans_serif.tap{|font| font.size=24}
    
    # テキストボックスを作成
    # 表示文字数[縦,横]、使用フォント、キー待ちカーソル、選択カーソルを渡す
    @box = TextBox.new(
            :size => [20, 8],
            :font => @font,
            :sc => @sc,
            :wc => @wc)
    # テキストボックスの背景を作成
    # テキストボックスの大きさより上下左右に、4ピクセルのマージンを付ける
    @box_bg = Sprite.new(:size=>[@box.w+8, @box.h+8], :type=>:ac)
    # 半透明の黒で塗りつぶし
    @box_bg.fill([0,0,0,128])
    
    # テキストボックスとその背景を一つのオブジェクトにまとめる
    # Partsクラスを使用
    @tbox = Parts.new(@box_bg.layout_size)
    # まず、背景を登録(テキストボックスより後ろに描画させるため)
    # (Partsクラスでは、原則登録順に描画する)
    @tbox[:bg] = @box_bg
    @tbox[:box] = @box

    # 各要素ををPartsの中心に移動させる
    @tbox[:bg].centering!
    @tbox[:box].centering!

    # Partsを移動させる
    # center!で、画面上の横の中心に移動
    # bottom!{...}で、画面上の下端から、画面高さ(base)の5パーセント上の位置に移動
    # (下端きっちりだと、キー待ちカーソルが表示されないため)
    @tbox.center!.bottom!{|base| 5.percent(base)}

    @se = Se.new
    @se.setup(@tbox){|box|
      select_textbox(box[:box], box)
    }
    
    @se.bgs[:bg] = Sprite.new(:file=>"image/bg.jpg",:type=>:as).centering!
    @se.visibles[:misasagi] = Sprite.new(:file=>"image/misasagi2.png",:type=>:ac).center!.bottom!
    
    @base = SampleTemp.new
  end
    
  # シーン内の内部処理メソッド
  def execute
    @se.start_plot(@base, nil, @commands, @janken){|com, janken|
      # 勝敗表
      # @res[0] => あいこの数
      # @res[1] => 勝ちの数
      # @res[2] => 負けの数
      @res = [0, 0, 0]
      
      # テキストボックスに文字列を描画
      text "じゃんけん、しよ。"
      # キーが押されるまで待つ
      pause
      # テキストボックスの描画内容を消去
      clear
      # キャンセルされるまでループ
      loop do
        text "じゃーんけーん・・・"
        # 1行改行
        cr
        # 用意しておいたコマンドを選択
        command com
        # コマンド選択をキャンセル(Xキー、Escキー、2ボタンを押した、または右クリックした)
        break if select_result == Se::Canceled
        
        # プレイヤーの結果:選択結果(guu,choki,paa)
        my = select_result
        # コンピュータ側は、ランダムで選択
        # keys method : {"guu"=>0, "choki"=>1 , "paa"=>2} => ["guu","choki","paa"]
        # sample method : 配列の要素をランダム(引数で渡した数、引数無しのときは1個)で返す
        you = janken.keys.sample

        # resultの値が0：あいこ
        #             -2,1：プレイヤーの勝ち
        #             -1,2：コンピューターの勝ち
        # この値を、3要素の配列のインデックスとすると、
        # 自然と同じ場所をアクセスすることになる
        result = janken[you] - janken[my]
        # 勝敗表を更新
        @res[result] += 1

        clear
        text "ぽん！"
        cr
        
        # ブロック無いの文字列を赤色で描画
        color(:red){  text "あなた: #{my}" }
        # 1行改行
        cr
        # ブロック無いの文字列を水色で描画
        color(:cyan){ text "わたし: #{you}" }
        # 2行改行
        cr(2)

        # 結果によって表示する文字列を変える
        case result
          when 0
            text "あいこね。"
          when -2,1
            text "あなたの勝ちね。"
          when -1,2
            text "わたしの勝ちね。"
        end
        cr(2)

        text "[勝敗]"
        color(:red){  text "win: #{@res[1]} " }
        color(:cyan){ text "lose: #{@res[2]}" }
        cr
        pause
        clear
      end
    }
  
    return nil
  end
end

st = SimpleStory.new
st.run(MainScene)
