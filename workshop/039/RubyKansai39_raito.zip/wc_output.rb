#! ruby -Ks

class WcOutput
  def initialize(init_info)
    init_datasource(init_info)
  end
  
  def init_datasource(init_info)
    @datasource = init_info
  end
  
  def open(&block)
    raise "WcOutput#open needs a block" unless block_given?
    yield $stdout
  end
  
  def make_row(ary_or_str)
    if ary_or_str.kind_of?(Array)
      ary_or_str.join("\t")
    else
      ary_or_str
    end
  end
  
  def write(ary_or_str)
    open do |io|
      io.puts make_row(ary_or_str)
    end
  end
end

class WcOutputIntoFile < WcOutput
  def init_datasource(init_info)
    @datasource = {:path => init_info}
  end
  
  def update_mode
    if File.file?(@datasource[:path])
      @datasource[:mode] = 'a'
    elsif not File.exist?(@datasource[:path])
      @datasource[:mode] = 'w'
    else
      raise "Cannot open the File!: #{@datasource[:path]}"
    end    
  end
  
  def open(&block)
    raise "WcOutput#open needs a block" unless block_given?
    update_mode
    begin
      File.open(@datasource[:path], @datasource[:mode]) do |io|
          yield io
      end
    rescue => e
      $stderr.puts $!
      $stderr.puts e.backtrace
    end
  end
end

