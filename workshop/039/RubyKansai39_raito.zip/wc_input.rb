#! ruby -Ks 

class WcInput
  attr_reader :datasource
  def initialize(init_info)
    init_datasource(init_info)
  end
  
  def init_datasource(init_info)
    @datasource = init_info
  end
  
  def open(&block)
    raise "WcInput#open needs a block" unless block_given?
    yield $stdin
  end
  
  def read(&block)
    raise "WcInput#read needs a block" unless block_given?
    open do |io|
      while line = io.gets do
        yield line
      end
    end
  end
end

class WcInputFromFiles < WcInput
  def init_datasource(init_info)
    @datasource ||= []
    if File.file?(init_info)
      # p init_info
      @datasource << init_info
    elsif File.directory?(init_info)
      Dir.glob("#{init_info}/*").each do |path|
        init_datasource(path)
      end
    else
      raise "File not found: #{init_info}"
    end    
  end
  
  def open(&block)
    raise "WcInput#open needs a block" unless block_given?
    begin
      @datasource.each do |path|
        File.open(path, 'rb') do |io|
          yield io
        end
      end
    rescue => e
      $stderr.puts $!
      $stderr.puts e.backtrace
    end
  end
end

class WcInputFromSTDIN < WcInput
  def open(&block)
    raise "WcInput#open needs a block" unless block_given?
    begin
      $stdin.binmode
      yield $stdin
    rescue => e
      $stderr.puts $!
      $stderr.puts e.backtrace
    end
  end  
end

