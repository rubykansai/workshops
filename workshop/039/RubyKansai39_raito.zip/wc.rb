#! ruby -Ks

require 'wc_input'
require 'wc_output'
require 'nkf'

module ConvToSJIS
  def conv(str)
    NKF.nkf('-s', str)
  end
end

class Wc
  def self.run(paths = [])
    output = WcOutput.new(nil)
    #output = WcOutputIntoFile.new('outfile3.txt')
    header = %w(Line Word Char Byte Path)
    output.write header
    if not paths.empty?
      total = paths.inject([0,0,0,0]) do |t, path|
        if ret = exec_wc(output, path)
          t.zip(ret).map{|x,y| x+y}
        else
          t
        end
      end
      if paths.size > 1
        total << 'total'
        output.write total
      end
    else
      ret = exec_wc(output, nil)
    end
    #words.each_pair { |name, val| puts "#{name}:\t#{val}" }
  end
  
  # input_info: path or nil(stdin) or others
  def self.exec_wc(output, input_info)
    begin
      wc = self.new(input_info)
      ret = wc.read
      ret << input_info  if  input_info
      output.write ret
      ret
    rescue => e
      $stderr.puts $!
      # $stderr.puts e.backtrace
      nil
    end
  end
  
  def initialize(init_info, separator=nil)
    choose_input(init_info)
    @separator = separator
  end
  
  def conv(line); line; end
  
  def choose_input(init_info)
    if init_info.kind_of?(String)
      klass = WcInputFromFiles
    elsif init_info.nil?
      klass = WcInputFromSTDIN
    else
      raise "Unknown type: init_info(#{init_info.inspect})"
    end
    @input = klass.new(init_info)
    self.extend ConvToSJIS 
  end
  
  def read
    n_lines = 0
    n_words = 0
    n_chars = 0
    n_bytes = 0
    last_line = ""
    ret = [0, 0, 0]
    @input.read do |line|
      last_line = line
      n_lines += 1 if last_line[-1,1] == "\n"
      n_words += (ret[0] = line.split(@separator).size)
      n_chars += (ret[1] = conv(line).split(//s).size)
      n_bytes += (ret[2] = line.length)
      yield line, ret if block_given?
    end
    [n_lines, n_words, n_chars, n_bytes]    
  end  
end

if $0 == __FILE__
  WC = Wc
  paths = ARGV  #.select{|path| File.exist?(path) } # and File.file?(path)}
  WC.run(paths)
end
