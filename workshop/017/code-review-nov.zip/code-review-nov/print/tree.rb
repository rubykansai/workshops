     1	class Tree
     2	  def initialize(data)
     3	    @data = data
     4	    @left = nil
     5	    @right = nil
     6	  end
     7	
     8	  def add(data)
     9	    case
    10	    when @data > data
    11	      add_left(data)
    12	    when @data < data
    13	      add_right(data)
    14	    else
    15	      false
    16	    end
    17	  end
    18	
    19	  def trace(data)
    20	    case
    21	    when @data == data
    22	      puts data
    23	      return true
    24	    when @data > data
    25	      trace_left(data)
    26	    when @data < data
    27	      trace_right(data)
    28	    end
    29	  end
    30	
    31	  private
    32	
    33	  def add_left(data)
    34	    @left ||= Tree.new(data)
    35	    @left.add(data)
    36	    # __add__(data, "left")
    37	  end
    38	
    39	  def add_right(data)
    40	    @right ||= Tree.new(data)
    41	    @right.add(data)
    42	    # __add__(data, "right")
    43	  end
    44	
    45	  def trace_left(data)
    46	    if @left.nil?
    47	      not_found
    48	    else
    49	      print "#{@data}-L-"
    50	      @left.trace(data)
    51	    end
    52	    # __trace__(data, "left")
    53	  end
    54	
    55	  def trace_right(data)
    56	    if @right.nil?
    57	      not_found
    58	    else
    59	      print "#{@data}-R-"
    60	      @right.trace(data)
    61	    end
    62	    # __trace__(data, "right")
    63	  end
    64	
    65	  def __trace__(data, direction)
    66	    if child = instance_variable_get("@#{direction}")
    67	      print "#{@data}-#{direction.slice(0, 1).upcase}-"
    68	      child.trace(data)
    69	    else
    70	      not_found
    71	    end
    72	  end
    73	
    74	  def not_found
    75	    puts " not found!"
    76	    return false
    77	  end
    78	
    79	  def __add__(data, direction)
    80	    instance_eval %{
    81	      @#{direction} ||= Tree.new(data)
    82	      @#{direction}.add(data)
    83	    }
    84	  end
    85	end
    86	
    87	if __FILE__ == $0
    88	  numbers = [17, 20, 13, 32, 47, 9, 50, 48]
    89	  tree = Tree.new(25)
    90	
    91	  puts numbers.join(" ")
    92	  numbers.each do |number|
    93	    tree.add(number)
    94	  end
    95	  STDIN.each_line do |input|
    96	    tree.trace(input.to_i)
    97	  end
    98	end
