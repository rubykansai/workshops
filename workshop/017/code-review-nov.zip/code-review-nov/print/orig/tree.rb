     1	#!/usr/local/bin/ruby
     2	# tree.rb 
     3	class Tree 
     4	  # �錾���ꂽ�c���[������������B
     5	  def initialize(data) 
     6	    @data = data
     7	    @lson = nil; # �������ɂ͎q�������Ȃ��B
     8	    @rson = nil
     9	  end
    10	  # �c���[�Ƀf�[�^��ǉ�����
    11	  def add(data)
    12	    if @data > data
    13	      if @lson != nil
    14		@lson.add(data)
    15	      else
    16		@lson = Tree.new(data)
    17	      end
    18	    elsif @data < data
    19	      if @rson != nil
    20		@rson.add(data)
    21	      else
    22		@rson = Tree.new(data)
    23	      end
    24	    else
    25	      return false
    26	    end
    27	  end
    28	  # �f�[�^�ւ̃p�X��\������B
    29	  def trace(data)
    30	    if @data == data
    31	      print data, "\n"
    32	      return true
    33	    end
    34	    if  data < @data
    35	      if @lson == nil 
    36		print " not found!\n"
    37		return false
    38	      else
    39		print @data, "-L-"
    40		@lson.trace(data)
    41	      end
    42	    else
    43	      if @rson == nil 
    44		print " not found!\n"
    45		return false
    46	      else
    47		print @data, "-R-"
    48		@rson.trace(data)
    49	      end
    50	    end
    51	  end
    52	end
    53	################ Main Program ###############
    54	STDOUT.sync = true
    55	numbers = [17,20,13,32,47,9,50,48]
    56	tree = Tree.new(25)  # ���[�g��25 �Ƃ��Ă���
    57	
    58	for a in numbers     
    59	  tree.add(a)
    60	  printf("%d ",a)
    61	end
    62	print "\n"
    63	while true
    64	  s = gets.chop
    65	  if s == ""
    66	    break
    67	  else
    68	    key = s.to_i
    69	    tree.trace(key)  
    70	  end
    71	end
    72	
    73	
    74	
