class Tree
  def initialize(data)
    @data = data
    @left = nil
    @right = nil
  end

  def add(data)
    case
    when @data > data
      add_left(data)
    when @data < data
      add_right(data)
    else
      false
    end
  end

  def trace(data)
    case
    when @data == data
      puts data
      return true
    when @data > data
      trace_left(data)
    when @data < data
      trace_right(data)
    end
  end

  private

  def add_left(data)
    @left ||= Tree.new(data)
    @left.add(data)
    # __add__(data, "left")
  end

  def add_right(data)
    @right ||= Tree.new(data)
    @right.add(data)
    # __add__(data, "right")
  end

  def trace_left(data)
    if @left.nil?
      not_found
    else
      print "#{@data}-L-"
      @left.trace(data)
    end
    # __trace__(data, "left")
  end

  def trace_right(data)
    if @right.nil?
      not_found
    else
      print "#{@data}-R-"
      @right.trace(data)
    end
    # __trace__(data, "right")
  end

  def __trace__(data, direction)
    if child = instance_variable_get("@#{direction}")
      print "#{@data}-#{direction.slice(0, 1).upcase}-"
      child.trace(data)
    else
      not_found
    end
  end

  def not_found
    puts " not found!"
    return false
  end

  def __add__(data, direction)
    instance_eval %{
      @#{direction} ||= Tree.new(data)
      @#{direction}.add(data)
    }
  end
end

if __FILE__ == $0
  numbers = [17, 20, 13, 32, 47, 9, 50, 48]
  tree = Tree.new(25)

  puts numbers.join(" ")
  numbers.each do |number|
    tree.add(number)
  end
  STDIN.each_line do |input|
    tree.trace(input.to_i)
  end
end
