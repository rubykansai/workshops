require 'shain1'

class Shacho
  def meirei(type)
    case type
    when "Tanto"
      shain = Tanto.new
    when "Shunin"
      shain = Shunin.new
    when "Bucho"
      shain = Bucho.new
    end

    shain.standup
  end
end

shacho = Shacho.new
shacho.meirei(ARGV[0])
