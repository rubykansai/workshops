require 'shain3'

class Shacho
  def meirei(type, kihonkyu)
    case type
    when "Tanto"
      shain = Tanto.new
    when "Shunin"
      shain = Shunin.new
    when "Bucho"
      shain = Bucho.new
    when "Torishimariyaku"
      shain = Torishimariyaku.new
    end

    shain.standup
    puts "������ #{shain.kyuryo(kihonkyu)} �ߤǤ���"
  end
end

shacho = Shacho.new
shacho.meirei(ARGV[0], ARGV[1].to_i)
