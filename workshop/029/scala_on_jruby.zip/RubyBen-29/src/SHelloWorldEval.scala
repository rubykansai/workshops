import javax.script._

object SHelloWorldEval extends Application {
  val engineManager = new ScriptEngineManager
  val engine = engineManager.getEngineByName("ruby")
  val result = engine.eval("sum = 0; (1..10).each {|i| sum += i}; sum")
  println(result)
}
