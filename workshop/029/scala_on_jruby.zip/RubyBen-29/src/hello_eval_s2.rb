require "java"

include_class "examples.EvalScala"

result = EvalScala::eval("var sum = 0; 1 to 10 foreach {i => sum += i}; sum")
puts result
