require "java"

include_class "scala.tools.nsc.Interpreter"
include_class "scala.tools.nsc.Settings"

interpreter = Interpreter.new(Settings.new(nil))
interpreter.beQuiet
interpreter.interpret(
  "var sum = 0; 1 to 10 foreach {i => sum += i}; println(sum)")
