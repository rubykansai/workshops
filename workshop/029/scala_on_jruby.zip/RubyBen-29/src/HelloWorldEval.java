import javax.script.*;

public class HelloWorldEval {
  public static void main(String[] args) throws Exception {
    ScriptEngineManager engineManager = new ScriptEngineManager();
    ScriptEngine engine = engineManager.getEngineByName("ruby");
    Object result = engine.eval("sum = 0; (1..10).each {|i| sum += i}; sum");
    System.out.println(result);
  }
}
