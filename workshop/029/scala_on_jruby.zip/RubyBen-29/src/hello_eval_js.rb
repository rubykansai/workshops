require "java"

include_class "javax.script.ScriptEngine"
include_class "javax.script.ScriptEngineManager"

engineManager = ScriptEngineManager.new
engine = engineManager.getEngineByName("js");
result = engine.eval("var sum = 0; for (var i = 1; i <= 10; i++) {sum += i}; sum");
puts result
