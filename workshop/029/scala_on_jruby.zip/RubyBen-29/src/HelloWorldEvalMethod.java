import javax.script.*;

import org.jruby.Ruby;
import org.jruby.runtime.builtin.IRubyObject;
import org.jruby.runtime.ThreadContext;

public class HelloWorldEvalMethod {
  public static void main(String[] args) throws Exception {
    ScriptEngineManager engineManager = new ScriptEngineManager();
    ScriptEngine engine = engineManager.getEngineByName("ruby");
    IRubyObject rubyObj = (IRubyObject)engine.eval(
      "class Foo; def name; \"foo\"; end; end; Foo.new");
    ThreadContext threadContext = Ruby.newInstance().getCurrentContext();
    System.out.println(rubyObj.callMethod(threadContext, "name"));
  }
}
