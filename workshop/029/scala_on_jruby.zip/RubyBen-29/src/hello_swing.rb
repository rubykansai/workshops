require "java"

include_class "java.awt.Font"
include_class "java.awt.Color"
include_class "javax.swing.JLabel"
include_class "javax.swing.JFrame"

title = "Hello, world!"

label = JLabel.new(title)
label.setForeground(Color::RED)
label.setFont(Font.new("Serif", Font::ITALIC, 128))

frame = JFrame.new(title)
frame.setDefaultCloseOperation(JFrame::EXIT_ON_CLOSE)
frame.add(label)
frame.pack

frame.setVisible(true)
