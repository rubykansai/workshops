package examples

class Result(var value: Any) {
  def this() = this(null)
}
