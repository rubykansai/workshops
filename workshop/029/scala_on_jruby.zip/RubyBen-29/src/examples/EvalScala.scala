package examples

import scala.tools.nsc._

object EvalScala {
  def eval(source: String): Any = {
    val result = new Result(null)
    val interpreter = new Interpreter(new Settings(null))
    interpreter.beQuiet
    interpreter.bind("__result__", "examples.Result", result)
    interpreter.interpret("__result__.value = {" + source + "}")
    result.value
  }
}
