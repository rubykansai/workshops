#!/usr/bin/ruby
# 方針その 2
# まじめにクラス設計する

require 'singleton'

class Janken
  # 今回の仕様に合わせて人間対コンピュータで初期化
  def initialize
    @players = [HumanPlayer.new('人間'), ComputerPlayer.new('コンピュータ')]
  end

  # ゲームを実行
  def run
    # 基本ループでじゃんけんを実行しつづける
    loop do
      @players.each do |player|
        player.hand!
        player.game_count!
      end
      judge
    end
  rescue StopGameError
    # 結果表示
    @players.each do |player|
      puts "#{player.name} の勝率は #{player.rate} % です。"
      case player.rate
      when 0..30
        puts "#{player.name} は弱いですね。"
      when 31..65
        puts "#{player.name} はまあまあですね。"
      when 66...100
        puts "#{player.name} は強いですね。"
      when 100.0
        puts"#{player.name} は神ですね。"
      end
    end
  end

  # 勝敗を判定して結果表示
  def judge
    result = @players.inject(0b000){|res, player| res |= player.hand.hand_id }
    case result
    when Hand::ROCK,Hand::SCISSORS,Hand::PAPER
      # あいこ
      @players.each do |player|
        player.draw_count!
      end
      puts 'あいこ'
    when Hand::ROCK|Hand::SCISSORS|Hand::PAPER
      # 三人以上のときだけ意味がある
      @players.each do |player|
        player.draw_count
      end
      puts 'あいこ'
    else
      # 勝者の勝数をプラスする
      winers = @players.select do |player|
        player.hand.stronger?(result ^ player.hand.hand_id)
      end
      winers.each do |winer|
        winer.win_count!
        puts "#{winer.name} の勝ちです"
        puts "#{winer.name} の #{winer.win_count} 勝 "<<
          "#{winer.lose_count} 敗 #{winer.draw_count} 分 です。"
      end
    end
  end
end

# singleton クラスにして定数のように扱う
class Hand
  include Singleton
  
  ROCK     = 0b001
  SCISSORS = 0b010
  PAPER    = 0b100
  
  attr_reader :name
  attr_reader :rival
  attr_reader :hand_id
  
  def stronger?(other)
    other == @rival
  end

  def to_s
    @hand
  end

  class Rock < Hand
    def initialize
      @name = 'ぐー'
      @rival = SCISSORS
      @hand_id = ROCK
    end
  end

  class Scissors < Hand
    def initialize
      @name = 'ちょき'
      @rival = PAPER
      @hand_id = SCISSORS
    end
  end

  class Paper < Hand
    def initialize
      @name = 'ぱー'
      @rival = ROCK
      @hand_id = PAPER
    end
  end
end

# じゃんけんプレイヤーの基底クラス
# 人間とコンピュータに共通のメソッドや属性を定義
class Player
  attr_reader :game_count, :win_count, :draw_count, :name
  attr_accessor :hand

  def initialize(name)
    @name = name
    @game_count = 0
    @win_count = 0
    @draw_count = 0
  end

  # 出す手を決めるが、必ずサブクラスで実装させる。
  def hand!
    raise 'must implement!'
  end
  
  def win_count!
    @win_count += 1
  end

  def draw_count!
    @draw_count += 1
  end
  
  def game_count!
    @game_count += 1
  end

  def lose_count
    count = @game_count - @win_count - @draw_count
    count < 0 ? 0 : count
  end
  
  def rate
    @win_count / @game_count.to_f * 100
  end
end

# 人間クラス
class HumanPlayer < Player
  # 人間の手は標準入力から入力させる。
  def hand!
    loop do
      puts '手を入力してください'
      print 'G:ぐー, C:ちょき, P:ぱー > '
      case STDIN.gets.chomp!.upcase
      when 'G'
        @hand = Hand::Rock.instance
      when 'C'
        @hand = Hand::Scissors.instance
      when 'P'
        @hand = Hand::Paper.instance
      when 'Q'
        # 終了時は例外を発生させる
        raise StopGameError
      else
        # 想定外の文字が来たらループの始めに戻る
        redo
      end
    end
  end
end

# コンピュータクラス
class ComputerPlayer < Player
  # コンピュータの手はランダム
  def hand!
    case rand(3)
    when 0
      @hand = Hand::Rock.instance
    when 1
      @hand = Hand::Scissors.instance
    when 2
      @hand = Hand::Paper.instance
    end
  end
end

# ゲーム終了用例外
class StopGameError < StandardError
end

# $0:実行されたファイル名
# __FILE__:このファイルの名前
# Ruby でコマンドラインツールを作成するときのイディオム
if $0 == __FILE__
  janken = Janken.new
  janken.run
end
