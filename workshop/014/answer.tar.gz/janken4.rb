#!/usr/bin/ruby
# 方針その 4
# irb の設定をごにょごにょする

# まずはうじひささんによるオリジナルを。
# 使い方
# irbを起動してこのファイルを load するだけ。
# コメントは、okkez によるものです。

# 全ての元になるじゃんけんクラス
class Junken
  # 初期化。
  # 引数にハッシュを指定するとある程度回数を積んだ状態から
  # スタートできるようです。
  def initialize(hash = {})
    # 多重代入ですね。
    @win, @lose, @count = hash[:win], hash[:lose], hash[:count]
    @win ||= 0
    @lose ||= 0
    @count ||= 0
  end

  # この辺のロジックはもう少しよくできるはず。
  def g
    "あたたの手: グー\n" <<
    case rand(3)
    when 0
      draw
      "コンピュータの手: グー\n" <<
      "引き分けです。\n"
    when 1
      win
      "コンピュータの手: チョキ\n" <<
      "あなたの勝ちです。\n"
    else
      lose
      "コンピュータの手: パー\n" <<
      "コンピュータの勝ちです。\n"
    end
  end

  def c
    "あたたの手: チョキ\n" <<
    case rand(3)
    when 0
      draw
      "コンピュータの手: チョキ\n" <<
      "引き分けです。\n"
    when 1
      win
      "コンピュータの手: パー\n" <<
      "あなたの勝ちです。\n"
    else
      lose
      "コンピュータの手: グー\n" <<
      "コンピュータの勝ちです。\n"
    end
  end

  def p
    "あたたの手: パー\n" <<
    case rand(3)
    when 0
      draw
      "コンピュータの手: パー\n" <<
      "引き分けです。\n"
    when 1
      win
      "コンピュータの手: グー\n" <<
      "あなたの勝ちです。\n"
    else
      lose
      "コンピュータの手: チョキ\n" <<
      "コンピュータの勝ちです。\n"
    end
  end

  def win
    @win += 1
    @count += 1
  end

  def lose
    @lose += 1
    @count += 1
  end

  def draw
    @count += 1
  end

  def rate
    # to_fしてるのは、浮動小数点で計算させるため。
    100 * @win / @count.to_f
  end
end

# ここからがポイントです。
# irb では、式を実行したあと返り値に対してinspectされた結果を
# 表示しようとします。大抵の場合、to_sとinspectは同じことをするので
# ここでは、to_s を使っているようです。
# 実行してみればわかりますが、ユーザーが G [RET]とプロンプト上で
# 入力すると、irb によって自動的にG.to_s が呼ばれ、結果が表示されます。
class G
  def self.to_s
    $junken.g
  end
end

class C
  def self.to_s
    $junken.c
  end
end

class P
  def self.to_s
    $junken.p
  end
end

class Q
  def self.to_s
    puts "終了します。\n" <<
    "あなたの勝率は#{$junken.rate}%です。弱いですね。\n" <<
    "さようなら\n"
    exit
  end
end

# じゃんけんゲームに適したプロンプトに変更
conf.return_format = "%s\n"
conf.prompt_i = "手を入力してください(G: ぐー, C: ちょき, P: ぱー, Q: 終了)\n> "

# 結果を保存しなければならないのでグローバル変数を使用する。
$junken = Junken.new

# これ以降は irb がやってくれる
