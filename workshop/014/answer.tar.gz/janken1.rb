#!/usr/bin/ruby
# 方針その 1
ROCK = 0
SCISSORS = 1
PAPER = 2

HANDS = {'G' => ROCK, 'C' => SCISSORS, 'P' => PAPER}
HANDS_NAME = %w[ぐー ちょき ぱー]

def judge(player, computer)
  (player - computer) % 3
end

win_count = 0
total_count = 0

puts 'じゃんけんゲームを開始します。'
# 何回もじゃんけんするので基本ループ
loop do
  puts '手を入力してください。G:ぐー,C:ちょき,P:ぱー,Q:終了'
  print '> '
  player_hand = STDIN.gets.chomp!.upcase
  break if 'Q' == player_hand
  # ハッシュのキーに存在しない文字なら、もう一度手を入力させる
  next unless HANDS.keys.include?(player_hand)
  computer_hand = rand(3)
  puts "あなたの手 #{HANDS_NAME[HANDS[player_hand]]}"
  puts "コンピュータの手 #{HANDS_NAME[computer_hand]}"
  total_count += 1
  case judge(HANDS[player_hand],computer_hand)
  when 0
    puts 'あいこです'
  when 1
    puts 'コンピュータの勝ち'
  when 2
    puts 'プレイヤーの勝ち'
    win_count += 1
  end
end

# 勝率計算
win_rate = (win_count / total_count.to_f) * 100

puts 'あなたの勝率は %f %%' % win_rate
# 気の利いたメッセージは略
