#!/usr/bin/ruby
# 方針その 3
# ワンライナーで

# にしはたくんによるワンライナー
puts "#{print "0: rock\n1: scissors\n2: paper\ninput 0, 1 or 2: "}player: #{["rock", "scissors", "paper"][player = gets.to_i]}\tcom: #{["rock", "scissors", "paper"][com = rand(3)]}\nresult: #{{0 => "draw", 1 => "lose", 2 => "win"}[(player - com) % 3]}"

# ちょっと短くしてみた
puts "#{print "0: rock\n1: scissors\n2: paper\ninput 0, 1 or 2: "}player: #{(hands=[:rock, :scissors, :paper])[player = gets.to_i]}\tcom: #{hands[com = rand(3)]}\nresult: #{[:draw,:lose, :win][(player - com) % 3]}" 

# 結局どっちにしても今回の演習問題の仕様は満たしていないのでアウトなんですけど。
