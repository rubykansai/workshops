#!/usr/bin/ruby
# 石取りゲーム
# メソッドやクラスを定義しないバージョン

count = 0
count = rand(100) + 1 until count > 9

puts "石は #{count} 個です。"

# 先手、後手を選択する
mode = nil
loop do
  puts "先手か後手か選んでください。"
  print "1 : 先手, 2 : 後手 > "
  mode = STDIN.gets.chomp.to_i
  case mode
  when 1
    puts "あなたが先手です"
  when 2
    puts "あなたが後手です"
  else
    next
  end
  break
end

while count > 0
  case mode
  when 1
    # 人間が石を取る
    stones = 0
    begin
      print "石を取ってください [1-3] > "
      stones = STDIN.gets.chomp.to_i 
    end  until 0 < stones and stones < 4  and count - stones >= 0
    puts "あなたは #{stones} 個取りました"
    mode = 2
  when 2
    # コンピュータが石を取る
    stones = case
             when (count - 1) % 4 == 1
               1
             when (count - 2) % 4 == 1
               2
             when (count - 3) % 4 == 1
               3
             else
               rand(3) + 1
             end
    puts "コンピュータは #{stones} 個取りました"
    mode = 1
  else
    raise 'must not happen'
  end
  count -= stones
  puts "残りの石は #{count} 個です"
  if count <= 0
    case mode
    when 1
      puts 'あなたの勝ちです'
    when 2
      puts "あなたの負けです"
    else
      raise 'must not happen'
    end
    break
  end
end
