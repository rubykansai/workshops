#!/usr/bin/ruby
# 石取りゲーム
# メソッドを定義するバージョン

def main
  # 石の初期個数を決定する
  count = rand(91) + 10
  puts "石は #{count} 個です。"
  # 先手、後手を決定する
  turn = select_turn until [1,2].include?(turn)
  # ゲーム開始
  while count > 0
    case turn
    when 1
      count -= human_get_stones(count)
      turn = 2
    when 2
      count -= computer_get_stones(count)
      turn = 1
    else
      raise 'must not happen'
    end
    puts "石は残り #{count} 個です"
  end
  judge(turn)
end

def select_turn
  puts '先手か後手か選択してください。'
  print "1 : 先手, 2 : 後手 > "
  STDIN.gets.to_i
end

def human_get_stones(count)
  begin
    print "石を取ってください [1-3] > "
    stones = STDIN.gets.to_i
  end until [1,2,3].include?(stones) and count - stones >= 0
  puts "あなたは #{stones} 個取りました"
  stones
end

def computer_get_stones(count)
  stones = case
           when (count - 1) % 4 == 1
             1
           when (count - 2) % 4 == 1
             2
           when (count - 3) % 4 == 1
             3
           else
             rand(3) + 1
           end
  puts "コンピュータは #{stones} 個取りました"
  stones
end

def judge(turn)
  case turn
  when 1
    puts 'あなたの勝ちです'
  when 2
    puts 'あなたの負けです'
  else
    raise 'must not happen'
  end
end

if __FILE__ == $0
  main
end
