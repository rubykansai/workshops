#!/usr/bin/ruby

count = 99

def bottles(count)
  if count == 1
    'Bottle'
  else
    'Bottles'
  end
end

def bar(count)
  str = <<-EOD
  #{count} #{bottles(count)} of beer on the wall
  #{count} #{bottles(count)} of beer
  Take one down and pass it around
  #{count - 1} #{bottles(count - 1)} of beer on the wall
  EOD
end

until count <= 0
  puts bar(count)
  count -= 1
end
