#!/usr/bin/ruby

count = 99

until count <= 0
  if count > 2
    puts <<-EOD
    #{count} Bottles of beer on the wall
    #{count} Bottles of beer
    Take one down and pass it around
    #{count - 1} Bottles of beer on the wall
    EOD
  elsif count == 2
    puts <<-EOD
    #{count} Bottles of beer on the wall
    #{count} Bottles of beer
    Take one down and pass it around
    #{count - 1} Bottle of beer on the wall
    EOD
  elsif count == 1
    puts <<-EOD
    #{count} Bottle of beer on the wall
    #{count} Bottle of beer
    Take one down and pass it around
    #{count - 1} Bottles of beer on the wall
    EOD
  end
  count -= 1
end
