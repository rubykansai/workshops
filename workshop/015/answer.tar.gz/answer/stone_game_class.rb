#!/usr/bin/ruby
# 石取りゲーム
# クラスを使うバージョン

class Player
  attr_reader :name
  
  def initialize(name = self.class)
    @name = name
  end
  
  def stones(count)
    raise 'must implement this method'
  end
  
  def lose?
    @lose
  end
end

class ComputerPlayer < Player
  def stones(count)
    1.step(3) do |n|
      stones = n if count - n % 4 == 1
    end
    begin
      stones ||= rand(3) + 1
    end until count - stones >= 0
    puts "コンピュータは #{stones} 個取りました"
    if count - stones <= 0
      @lose = true
    end
    stones
  end
end

class HumanPlayer < Player
  def stones(count)
    begin
      print "石を取ってください [1-3] > "
      stones = STDIN.gets.to_i
    end until [1,2,3].include?(stones) and count - stones >= 0
    puts "あなたは #{stones} 個取りました"
    if count - stones <= 0
      @lose = true
    end
    stones
  end
end

class GameMaster
  def initialize(count, player1, player2)
    @count = count
    @players = [player1, player2]
  end
  
  def self.select_turn
    puts '先手か後手か選択してください。'
    print "1 : 先手, 2 : 後手 > "
    STDIN.gets.to_i
  end
  
  def play
    while @count > 0
      @players.each do |player|
        @count -= player.stones(@count)
        break if @count <= 0
        puts "石は残り #{@count} 個です"
      end
    end
    puts "#{loser.name} の負けです"
  end
  
  private
  
  def loser
    @players.detect{|player| player.lose? }
  end
end

if __FILE__ == $0
  count = rand(91) + 10
  puts "石は #{count} 個です。"
  players = [HumanPlayer.new('人間'), ComputerPlayer.new('コンピュータ')]
  turn = GameMaster.select_turn until [1,2].include?(turn)
  players.reverse! if turn == 2
  m = GameMaster.new(count, *players)
  m.play
end
