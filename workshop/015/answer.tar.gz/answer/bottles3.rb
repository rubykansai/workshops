#!/usr/bin/ruby

def bottles(count)
  if count == 1
    'Bottle'
  else
    'Bottles'
  end
end

def bar(count)
  str = <<-EOD
  #{count} #{bottles(count)} of beer on the wall
  #{count} #{bottles(count)} of beer
  Take one down and pass it around
  #{count - 1} #{bottles(count - 1)} of beer on the wall
  EOD
end

99.downto(1) do |n|
  puts bar(n)
end

__END__

99.step(1,-1) do |n|
  puts bar(n)
end

1.upto(99) do |n|
  puts bar(100 - n)
end

for i in (1..99)
  puts bar(100 - i)
end

for i in (1..99).to_a.reverse
  puts bar(i)
end
