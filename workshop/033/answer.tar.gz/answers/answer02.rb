#!/usr/bin/ruby

puts (0..ARGV[0]).inject(:+)
