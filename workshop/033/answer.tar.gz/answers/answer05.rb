#!/usr/bin/ruby

require 'rubygems'
require 'fastercsv'

require 'optparse'

def main
  num = nil
  input_file = nil
  output_dir = nil
  prefix = 'output'
  parser = OptionParser.new
  parser.on('-n', '--split-num=NUM', 'split NUM files') do |n|
    num = n.to_i
  end
  parser.on('-i', '--input-file=FILENAME', 'specify input file name') do |path|
    input_file = path
  end
  parser.on('-o', '--output-dir=DIRNAME', 'specify output directory name') do |path|
    output_dir = path
  end
  parser.on('-p', '--prefix=PREFIX', 'prefix of output files') do |str|
    prefix = str
  end

  def parser.error(message)
    $stderr.puts message
    $stderr.puts self.help
    exit(1)
  end

  begin
    parser.parse!
  rescue => ex
    parser.error(ex.message)
  end

  if num.nil?
    parser.error('no --split-num')
  end

  if input_file.nil?
    parser.error('no input file')
  end

  if output_dir.nil?
    parser.error('no output file')
  end

  array = FasterCSV.read(input_file)
  div, mod = array.size.divmod(num)
  array.each_slice(div).with_index{|v, i|
    FasterCSV.open("#{output_dir}/#{prefix}#{i}.csv", 'w+') do |csv|
      v.each do |row|
        csv << row
      end
    end
  }
end

if __FILE__ == $0
  main
end
