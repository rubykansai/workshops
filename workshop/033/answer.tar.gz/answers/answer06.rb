#!/usr/bin/ruby
# -*- coding: utf-8 -*-

require 'optparse'

def main
  options = {
    :number_nonblank  => false,
    :number           => false,
    :squeeze_blank    => false,
    :show_nonprinting => false,
    :binary           => false,
    :show_ends        => false,
    :show_tabs        => false,
  }
  parser = OptionParser.new
  parser.on('-b', '--number-nonblank', '空白でない行に番号を付ける。初めの行を1行目とする。') do |v|
    options[:number_nonblank] = true
  end
  parser.on('-e', "‘-vE’ と同じ。") do |v|
    options[:show_nonprinting] = true
    options[:show_ends] = true
  end
  parser.on('-n', '--number', 'すべての行に番号を付ける。初めの行を 1行目とする。') do |v|
    options[:number] = true
  end
  parser.on('-s', '--squeeze-blank', "連続した空白行を、1つの空白行にまとめる。") do |v|
    options[:squeeze_blank] = true
  end
  parser.on('-t', "-vT’ と同じ。") do |v|
    options[:show_nonprinting] = true
    options[:show_tabs] = true
  end
  parser.on('-u', "何もしない。 Unix との互換性のために存在する。") do |v|
    # do nothing
  end
  parser.on('-v', '--show-nonprinting', <<-STR) do |v|
<LFD> と <TAB> とを除く制御文字を ‘^’ 表記を使って表示する。高位
ビットがセットされている文字は、前に ‘M-’ を置いて表わす。
    STR
    options[:show_nonprinting] = true
  end
  parser.on('-A', '--show-all', "‘-vET’ と同じ。") do |v|
    options[:show_nonprinting] = true
    options[:show_ends] = true
    options[:show_tabs] = true
  end
  parser.on('-B', '--binary', <<-STR) do ||
DOS プラットフォームのみ。ファイルの読み書きをバイナリモードで行う。
    STR
    options[:binary] = true
  end
  parser.on('-E', '--show-ends', "各行の最後に ‘$’ を表示する。") do |v|
    options[:show_ends] = true
  end
  parser.on('-T', '--show-tabs', "<TAB> 文字を ‘^I’ と表示する。") do |v|
    options[:show_tabs] = true
  end
  parser.on('--help', '標準出力に使用方法のメッセージを出力して正常終了する。') do
    puts parser.help
    exit(0)
  end
  parser.on('--version', '標準出力にバージョン情報を出力して正常終了する。') do
    parser.version = '0.0.1'
    puts parser.version
    exit(0)
  end

  def parser.error(message)
    $stderr.puts message
    $stderr.puts self.help
    exit(1)
  end

  begin
    parser.parse!
  rescue => ex
    parser.errpr(ex.message)
  end

  str = ARGF.read
  [
   :squeeze_blank,
   :number_nonblank,
   :number,
   :show_nonprinting,
   :show_ends,
   :show_tabs,
   :binary,
  ].each do |m|
    next if m == :number && options[:number_nonblank]
    str = __send__(m, str) if options[m]
  end
  print str
end

def number_nonblank(str)
  num = 0
  s = str.lines.to_a.size.to_s.size
  str.lines.map{|line|
    if /^$/ === line
      line
    else
      num += 1
      "\t%0#{s}d\t%s" % [num, line]
    end
  }.join
end

def number(str)
  s = str.lines.to_a.size.to_s.size
  str.lines.with_index.map{|line, i|
    "\t%0#{s}d\t%s" % [i+1, line]
  }.join
end

def squeeze_blank(str)
  str.gsub(/(:?\n){2,}/, "\n\n")
end

# 0x00 - 0x1F (+ 0x40) see ascii(7)
def show_nonprinting(str)
  (0x00..0x1f).each do |v|
    next if v == 0x09 # \t
    next if v == 0x0a # \n
    str = str.gsub(/#{v.chr}/, "^#{(v + 0x40).chr}")
  end
  str
end

def binay(str)
  # do nothing
end

def show_ends(str)
  str.gsub(/^(.*)$/, '\1$')
end

def show_tabs(str)
  str.gsub(/\t/, "^I")
end

if __FILE__ == $0
  main
end
