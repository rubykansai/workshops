#!/usr/bin/ruby

require 'optparse'

def main
  a = b = nil
  op = '+'
  parser = OptionParser.new
  parser.on('-l', '--left-value=NUM', 'The left value') do |n|
    a = n.to_i
  end
  parser.on('-r', '--right-value=NUM', 'The right value') do |n|
    b = n.to_i
  end
  parser.on('-o', '--operator=[OP]', 'Operator +,-,*,/') do |o|
    op = o
  end

  begin
    parser.parse!
  rescue => ex
    $stderr.puts ex.message
    $stderr.puts parser.help
    exit(1)
  end

  if a.nil? or b.nil?
    $stderr.puts 'you must specify both -l and -r options'
    $stderr.puts parser.help
    exit(1)
  end

  unless %w[+ - * /].include?(op)
    $stderr.puts "invalid operator: #{op}"
    $stderr.puts parser.help
    exit(1)
  end

  puts a.__send__(op, b)
end

if __FILE__ == $0
  main
end
