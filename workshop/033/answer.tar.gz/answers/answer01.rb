#!/usr/bin/ruby

a = ARGV[0].to_i
b = ARGV[1].to_i

puts a + b
puts a - b
puts a * b
puts a / b
