#!/usr/bin/ruby

require 'optparse'

def main
  min = 0
  max = nil
  parser = OptionParser.new
  parser.on('--min=[NUM]', 'min value (default is 0)') do |n|
    min = n.to_i
  end
  parser.on('--max=NUM', 'max value') do |n|
    max = n.to_i
  end

  def parser.error(message)
    $stderr.puts message
    $stderr.puts self.help
    exit(1)
  end

  begin
    parser.parse!
  rescue => ex
    parser.error(ex.message)
  end

  if max.nil?
    parser.error('must specify max value')
  end

  if max < min
    parser.error('min value must be smaller then max value')
  end

  puts (min..max).inject(:+)
end

if __FILE__ == $0
  main
end
