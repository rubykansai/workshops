require 'sample1'
require 'benchmark'

time = 10000

puts Benchmark.measure {
  sum = 0; i = 1
  time.times {sum += i; i += 1}
  puts sum
}

puts Benchmark.measure {
  puts sum(time)
}
