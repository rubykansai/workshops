#!/bin/sh

rm -f Sample1.o Sample1.dll
gcc -c Sample1.c "-IC:/Program Files/Java/jdk1.5.0_06/include" "-IC:/Program Files/Java/jdk1.5.0_06/include/win32"
dllwrap -k -def Sample1.def --driver-name gcc -o Sample1.dll Sample1.o
