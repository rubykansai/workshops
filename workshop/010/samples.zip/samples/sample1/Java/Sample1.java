public class Sample1 {

  static {
    try {
      System.out.println("Loading Sample1");
      System.loadLibrary("Sample1");
      System.out.println("Done.");
    } catch(Error e) {
      e.printStackTrace();
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  public static native long sum(long time);
}
