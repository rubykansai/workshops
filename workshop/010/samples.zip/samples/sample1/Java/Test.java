public class Test {
  public static void main(String[] args) throws Exception {
    System.out.println(Sample1.sum(10000));
  }
}
