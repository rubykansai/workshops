#include "Sample1.h"

/*
 * Class:     Sample1
 * Method:    sum
 * Signature: (J)J
 */
JNIEXPORT jlong JNICALL Java_Sample1_sum
  (JNIEnv* env, jclass cls, jlong time) {

  jlong i, sum = 0;
  for(i = 1; i <= time; i++) {
    sum += i;
  }

  return sum;
}
