# test3.rb

require "benchmark"
require "sound"
require "wave"

puts Benchmark.measure {
  org_sound = load_wave("wil1.wav")
  lpf_sound = Sound.new(org_sound.freq, fir_lpf(org_sound.dat, 4))
  save_wave(lpf_sound, "wil1_.wav")
  org_sound = load_wave("wil2.wav")
  hpf_sound = Sound.new(org_sound.freq, fir_hpf(org_sound.dat, 4))
  save_wave(hpf_sound, "wil2_.wav")
}
