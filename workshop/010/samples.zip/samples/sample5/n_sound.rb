# n_sound.rb

require "sample5"

class Sound

  attr_reader :freq, :dat

  def initialize(freq, dat)
    @freq = freq
    @dat = dat
  end

end

def fir_lpf(dat, level)
  return n_fir_lpf(dat, level)
end

def fir_hpf(dat, level)
  return n_fir_hpf(dat, level)
end
