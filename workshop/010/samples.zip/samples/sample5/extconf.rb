require "mkmf"

create_makefile("sample5")
