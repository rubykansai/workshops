# n_wave.rb

require "sample5"

def i4_to_str(val)
  val = val.to_i
  str = ""
  str << (val & 0xff).chr
  str << ((val >> 8) & 0xff).chr
  str << ((val >> 16) & 0xff).chr
  str << ((val >> 24) & 0xff).chr
  return str
end

def i2_to_str(val)
  val = val.to_i
  str = ""
  str << (val & 0xff).chr
  str << ((val >> 8) & 0xff).chr
  return str
end

def i1_to_str(val)
  val = val.to_i
  str = ""
  str << (val & 0xff).chr
  return str
end

def str_to_i4(str)
  return  str[0].to_i       | (str[1].to_i << 8) \
       | (str[2].to_i << 16) | (str[3].to_i << 24)
end

def str_to_i2(str)
  return  str[0].to_i | (str[1].to_i << 8)
end

def str_to_i1(str)
  return  str[0].to_i
end

def save_wave(sound, path)
  dat = n_i2a_to_str(sound.dat)
  File.open(path, "w") {|out|
    fileSize = 4 + 4 + 16 + 4 + 4 + dat.length
    out.print "RIFF"
    out.print i4_to_str(fileSize)
    out.print "WAVE"
    # fmt chunk
    out.print "fmt "
    # length of chunk
    out.print i4_to_str(16)
    # Format ID
    out.print i2_to_str(1)
    # Channel
    out.print i2_to_str(1)
    # Sampling rate
    out.print i4_to_str(sound.freq)
    # Data rate
    out.print i4_to_str(sound.freq * 1 * 2)
    # Block size
    out.print i2_to_str(1 * 2)
    # bit per sample
    out.print i2_to_str(16)
    # data chunk
    out.print "data"
    out.print i4_to_str(dat.length)
    out.print dat
  }
end

def load_wave(path)
  File.open(path, "r") {|inp|
    hRiff = inp.read(4)
    fileSize = str_to_i4(inp.read(4))
    hWave = inp.read(4)
    hFmt = inp.read(4)
    lenChunk = str_to_i4(inp.read(4))
    formatID = str_to_i2(inp.read(2))
    channel = str_to_i2(inp.read(2))
    rate = str_to_i4(inp.read(4))
    dataRate = str_to_i4(inp.read(4))
    block = str_to_i2(inp.read(2))
    bit = str_to_i2(inp.read(2))
    hData = inp.read(4)
    dataLen = str_to_i4(inp.read(4))
    dat = inp.read(dataLen)
    return Sound.new(rate, n_str_to_i2a(dat))
  }
end
