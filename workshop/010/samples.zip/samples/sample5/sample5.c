/*
 * sample5.c
 */

#include "ruby.h"

int string_length(VALUE rstr) {
  ID lengthID = rb_intern("length");
  VALUE rlength = rb_funcall(rstr, lengthID, 0);
  Check_Type(rstr, T_STRING);
  return FIX2INT(rlength);
}

void string_copy(VALUE rstring, int length, char* str) {
  int i;
  ID indexID = rb_intern("[]");
  ID toiID = rb_intern("to_i");
  for(i = 0; i < length; i++) {
    VALUE rvalue = rb_funcall(rstring, indexID, 1, INT2FIX(i));
    rvalue = rb_funcall(rvalue, toiID, 0);
    str[i] = (char)FIX2INT(rvalue);
  }
}

int array_length(VALUE rarray) {
  ID lengthID = rb_intern("length");
  Check_Type(rarray, T_ARRAY);
  VALUE rlength = rb_funcall(rarray, lengthID, 0);
  return FIX2INT(rlength);
}

void array_copy(VALUE rarray, int length, int* array) {
  int i;
  ID indexID = rb_intern("[]");
  ID toiID = rb_intern("to_i");
  for(i = 0; i < length; i++) {
    VALUE rvalue = rb_funcall(rarray, indexID, 1, INT2FIX(i));
    rvalue = rb_funcall(rvalue, toiID, 0);
    array[i] = FIX2INT(rvalue);
  }
}

VALUE array_new(int* array, int length) {
  int i;
  VALUE rarray = rb_ary_new2((long)length);
  for(i = 0; i < length; i++) {
    rb_ary_push(rarray, INT2FIX(array[i]));
  }
  return rarray;
}

VALUE n_i2a_to_str(VALUE self, VALUE rdat) {
  int length = array_length(rdat);
  int dat[length];
  array_copy(rdat, length, dat);
  char cdat[length * 2];
  int i;
  int index = 0;
  for(i = 0; i < length; i++) {
    int val = dat[i];
    cdat[index++] = val & 0xff;
    cdat[index++] = (val >> 8) & 0xff;
  }
  return rb_str_new(cdat, (long)(length * 2));
}

VALUE n_str_to_i2a(VALUE self, VALUE rstr) {
  int length = string_length(rstr);
  char str[length];
  string_copy(rstr, length, str);
  VALUE rdat = rb_ary_new2((long)(length / 2));
  int i;
  for(i = 0; i < length; i += 2) {
    int val = str[i] & 0xff | ((str[i + 1] & 0xff) << 8);
    if(val >= 32768) {
       val = val - 65536;
    }
    rb_ary_push(rdat, INT2FIX(val));
  }
  return rdat;
}

VALUE n_fir_lpf(VALUE self, VALUE rdat, VALUE rlevel) {

  int i, j, index, sigma;
  int length = array_length(rdat);
  int dat[length];
  int level = FIX2LONG(rlevel);
  int fir[level];
  int f_dat[length];

  array_copy(rdat, length, dat);

  for(i = 0; i < level; i++) {
    fir[i] = 0;
  }

  index = 0;
  for(i = 0; i < length; i++) {
    fir[index] = dat[i];
    sigma = 0;
    for(j = 0; j < level; j++) {
      sigma += fir[j];
    }
    f_dat[i] = sigma / level;
    index++;
    if(index >= level) {
      index = 0;
    }
  }

  VALUE rfdat = rb_ary_new2((long)length);
  for(i = 0; i < length; i++) {
    rb_ary_push(rfdat, INT2FIX(f_dat[i]));
  }

  return rfdat;
}

VALUE n_fir_hpf(VALUE self, VALUE rdat, VALUE rlevel) {

  int i, j, index, sigma;
  int length = array_length(rdat);
  int dat[length];
  int level = FIX2LONG(rlevel);
  int fir[level];
  int f_dat[length];

  array_copy(rdat, length, dat);

  for(i = 0; i < level; i++) {
    fir[i] = 0;
  }

  index = 0;
  for(i = 0; i < length; i++) {
    fir[index] = dat[i];
    sigma = 0;
    for(j = 0; j < level; j++) {
      sigma += fir[j];
    }
    f_dat[i] = dat[i] - sigma / level;
    index++;
    if(index >= level) {
      index = 0;
    }
  }

  VALUE rf_dat = array_new(f_dat, length);

  return rf_dat;
}

void Init_sample5(void) {
  rb_define_global_function("n_str_to_i2a", n_str_to_i2a, 1);
  rb_define_global_function("n_i2a_to_str", n_i2a_to_str, 1);
  rb_define_global_function("n_fir_lpf", n_fir_lpf, 2);
  rb_define_global_function("n_fir_hpf", n_fir_hpf, 2);
}
