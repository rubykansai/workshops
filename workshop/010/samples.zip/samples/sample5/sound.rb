# sound.rb

class Sound

  attr_reader :freq, :dat

  def initialize(freq, dat)
    @freq = freq
    @dat = dat
  end

end

def fir_lpf(dat, level)
  fir = []
  for i in 0..(level - 1)
    fir << 0.0
  end
  index = 0
  f_dat = []
  dat.each {|val|
    fir[index] = val
    sigma = 0.0
    fir.each {|v|
      sigma += v
    }
    f_dat << (sigma / fir.length.to_f)
    index += 1
    if index >= fir.length then index = 0 end
  }
  return f_dat
end

def fir_hpf(dat, level)
  fir = []
  for i in 0..(level - 1)
    fir << 0.0
  end
  index = 0
  f_dat = []
  dat.each {|val|
    fir[index] = val
    sigma = 0.0
    fir.each {|v|
      sigma += v
    }
    f_dat << (val - sigma / fir.length.to_f)
    index += 1
    if index >= fir.length then index = 0 end
  }
  return f_dat
end
