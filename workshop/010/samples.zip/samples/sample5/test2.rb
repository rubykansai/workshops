# test2.rb

require "benchmark"
require "n_sound"
require "n_wave"

length = 64000
dat = []
for i in 0..(length - 1)
  val = 5000.0 * Math::sin(Math::PI / 4 * i.to_f) \
      + 5000.0 * Math::sin(Math::PI / 16 * i.to_f)
  dat << val
end

puts Benchmark.measure {
  org_sound = Sound.new(16000, dat)
  lpf_sound = Sound.new(org_sound.freq, fir_lpf(org_sound.dat, 8))
  hpf_sound = Sound.new(org_sound.freq, fir_hpf(org_sound.dat, 4))
  save_wave(org_sound, "test.wav")
  save_wave(lpf_sound, "test2.wav")
  save_wave(hpf_sound, "test3.wav")
}
