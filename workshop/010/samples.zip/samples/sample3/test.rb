require 'sample3'

def concat(str1, str2)
  return str1.to_s + str2.to_s
end

begin
  puts greeting("Hello")
rescue => ex
  puts "#{ex.class}: #{ex}"
end

begin
  puts greeting(1)
rescue => ex
  puts "#{ex.class}: #{ex}"
end
