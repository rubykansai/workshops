require "mkmf"

create_makefile("sample3")
