require "mkmf"

create_makefile("sample4")
