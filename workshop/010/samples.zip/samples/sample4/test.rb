require 'sample4'

def concat(str1, str2)
  return str1.to_s + str2.to_s
end

result = greeting("Hello")

puts result
