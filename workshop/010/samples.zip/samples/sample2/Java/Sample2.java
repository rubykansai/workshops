public class Sample2 {

  static {
    try {
      System.loadLibrary("Sample2");
    } catch(Error e) {
      e.printStackTrace();
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  public Sample2() {
  }

  public native String greeting(String str);
}
