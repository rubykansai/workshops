#include "Sample2.h"

/*
 * Class:     Sample2
 * Method:    greeting
 * Signature: (Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_Sample2_greeting
  (JNIEnv * env, jobject obj, jstring str) {

  const char* _str2 = ", world!";
  size_t len2 = strlen(_str2);
  jstring str2 = NewStringUTF(env, _str2, len2);

  jchar* chars1 = GetStringChars(env, str, NULL);
  jsize length1 = GetStringLength(env, str);
  jchar* chars2 = GetStringChars(env, str2, NULL);
  jsize length2 = GetStringLength(env, str2);

  jsize length = length1 + length2;
  jchar result[length];

  memcpy(chars1, result, sizeof(jchar) * length1);
  memcpy(chars2, result + length1, sizeof(jchar) * length2);

  jstring resultStr = NewString(env, result, length);

  return resultStr;
}
