#!/bin/sh

rm -f Sample2.o Sample2.dll
gcc -c Sample2.c "-IC:/Program Files/Java/jdk1.5.0_06/include" "-IC:/Program Files/Java/jdk1.5.0_06/include/win32"
dllwrap -k -def Sample2.def --driver-name gcc -o Sample2.dll Sample2.o
