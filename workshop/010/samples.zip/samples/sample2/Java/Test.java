public class Test {
  public static void main(String[] args) throws Exception {
    Sample2 sample2 = new Sample2();
    String result = sample2.greeting("Hello");
    System.out.println(result);
  }
}
