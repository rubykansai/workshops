require 'sample2'

sample2 = Sample2.new
result = sample2.greeting("Hello")

puts result
