require "mkmf"

create_makefile("sample2")
