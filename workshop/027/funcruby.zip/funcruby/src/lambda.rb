f1 = lambda {|x, y| x + y}
f2 = lambda {|x, y| x * y}

def calc(f, x, y)
  f.call(x, y)
end

puts calc(f1, 1, 2)  # 1 + 2 = 3
puts calc(f2, 1, 2)  # 1 * 2 = 2
