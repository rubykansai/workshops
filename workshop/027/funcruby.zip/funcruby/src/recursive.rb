def loop(i, e)
  if i <= e
    i + loop(i + 1, e)
  else
    0
  end
end

puts loop(1, 10)  # 1 + 2 + ... + 10 = 55
