require "pattern_matching"

class Apple; end
class Grape; end

fruit = Apple.new

puts match(fruit) {
  with(Apple) {"apple"}
  with(String) {"hello"}
  otherwise {"unkown"}
}
