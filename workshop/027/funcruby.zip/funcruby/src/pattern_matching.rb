def match(value)

  def equals(arg1, arg2)
    if arg2.is_a?(Class)
      if arg1.respond_to?(:unapply)
        false # not implement
      else
        arg1.class == arg2 || args.class.is_a?(arg2)
      end
    else
      arg1 == arg2
    end
  end

  def with(arg)
    if !Thread.current[:match_matched]
      value = Thread.current[:match_value]
      if equals(value, arg)
        Thread.current[:match_matched] = true
        Thread.current[:match_result] = yield(value)
      end
    end
  end

  def otherwise
    if !Thread.current[:match_matched]
      Thread.current[:match_matched] = true
      Thread.current[:match_result] = yield(Thread.current[:match_value])
    end
  end

  Thread.current[:match_value] = value
  Thread.current[:match_matched] = false
  Thread.current[:match_result] = nil
  yield
  Thread.current[:match_result]

end

#value = "Foo"
#match(value) {
#  with(nil) {puts "nil"}
#  with(String) {puts "hello"}
#  with("Foo") {puts "foo"}
#  otherwise {puts "otherwise"}
#}
