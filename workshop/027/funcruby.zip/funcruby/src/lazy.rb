require "lazy_proc"

class Foo
  def initialize(name)
    puts "CREATED: Foo"
    @name = name
  end
  def name
    @name
  end
  def to_s
    "Foo[name=#{name}]"
  end
end


foo = lazy { Foo.new("Boo") }
puts "DEFINED lazy block."

puts foo.name
puts foo.to_s
