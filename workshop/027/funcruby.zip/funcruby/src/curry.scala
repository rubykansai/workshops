def add(x: Int)(y: Int) = x + y

val a2: Int => Int = add(2)

println(a2(3))  // 2 + 3 = 5
