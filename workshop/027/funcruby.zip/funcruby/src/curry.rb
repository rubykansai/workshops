def add(x)
  lambda {|y| x + y}
end

a2 = add(2)

puts a2.call(3)  # 2 + 3 = 5
