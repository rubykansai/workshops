def loop(i: Int, e: Int): Int =
  if (i <= e) i + loop(i + 1, e)
  else 0

println(loop(1, 10))  // 1 + 2 + ... + 10 = 55
