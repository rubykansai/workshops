class Lazy
  def initialize(&proc)
    @proc = proc
    @instance = nil
  end
  def method_missing(name, *args)
    __create
    eval("@instance.#{name}(*args)")
  end
  def to_s
    __create
    @instance.to_s
  end
  def __create()
    if @instance == nil
      @instance = @proc.call
    end
  end
end

def lazy(&proc)
  Lazy.new(&proc)
end
