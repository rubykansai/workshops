val f1 = {(x: Int, y: Int) => x + y}
val f2 = {(x: Int, y: Int) => x * y}

def calc(f: (Int, Int) => Int, x: Int, y: Int) = f(x, y)

println(calc(f1, 1, 2))  // 1 + 2 = 3
println(calc(f2, 1, 2))  // 1 * 2 = 2
