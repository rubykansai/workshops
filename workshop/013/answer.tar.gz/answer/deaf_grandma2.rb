require 'deaf_grandma'

module HearingAid
  def self.included(klass)
    klass.instance_eval{|obj|
      alias_method :talk_with_you_orig, :talk_with_you
      alias_method :speak_orig, :speak
      define_method(:talk_with_you){
        hear
        speak
        until /\Abye/i =~ @line
          hear
          speak
        end
        puts '���������褦�ʤ�'
      }
      define_method(:speak){
        puts "���䡼��#{year}ǯ����ʤ��͡�!!!" unless /\Abye/i =~ @line
      }
      private :speak
    }
  end
end

class DeafGrandma
  include HearingAid
end

if __FILE__ == $0
  DeafGrandma.new.talk_with_you
end
