# �����޿������Ѵ�
class Numeric
  OLD_ROMAN_UNIT = [1000, 500, 100, 50, 10, 5, 1].zip(%w[M D C L X V I])
  def to_old_roman
    number = self
    OLD_ROMAN_UNIT.inject('') do |r, elm|
      digit, number = number.divmod(elm[0])
      r + elm[1] * digit
    end
  end
end

1.step(1000) do |n|
# p [n, n.to_old_roman]
end

class Numeric
 ROMAN_UNIT = [1000,900,500,400,100,90,50,40,10,9,5,4,1].zip(%w(M CM D CD C XC L XL X IX V IV I))
 def to_roman
   number = self
   ROMAN_UNIT.inject("") do |r, elm|
     digit, number = number.divmod(elm[0])
     r + elm[1] * digit
   end
 end
end

1.step(1000) do |n|
# p [n, n.to_roman]
end

class Numeric
  alias to_old_roman_orig to_old_roman
  OLD_ROMAN_UNIT2 = {1000 => 'M',
                      500 => 'D',
                      100 => 'C',
                       50 => 'L',
                       10 => 'X',
                        5 => 'V',
                        1 => 'I'}

  def to_old_roman
    convert_num2roman(self, [1000, 500, 100, 50, 10, 5, 1])
  end
  private
  def convert_num2roman(n, m, str = '')
    return str if n == 0
    key = m.shift
    digit, n = n.divmod(key)
    convert_num2roman(n, m, str<<(OLD_ROMAN_UNIT2[key] * digit))
  end
end

1.step(1000) do |n|
  #p [n, n.to_old_roman]
end

arr1 = []; arr2 = []
1.step(1000){|n| arr1 << n.to_old_roman }
1.step(1000){|n| arr2 << n.to_old_roman_orig }
p arr1 - arr2
