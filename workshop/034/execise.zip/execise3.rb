def setup
  size 360,360 #�E�B���h�E�T�C�Y��ݒ�
  
  no_loop
end

def draw
  background 204
  
  no_fill
  stroke 104
  line width/2, 0,        width/2, height
  line 0,       height/2, width,   height/2
  
  grid(36,36,width/36,height/36){|x,y|
    point x,y
  }
  
  stroke_weight 3
  translate width/2,height/2
  
  #sin�`��
  stroke 255,0,0
  begin_shape
  curve_vertex -180,-90*sin(-180.radians)
  -180.step(180,30){|x|
    curve_vertex x,-90*sin(x.radians)
  }
  curve_vertex 180,-90*sin(180.radians)
  end_shape
  #cos�`��
  stroke 0,255,0
  begin_shape
  curve_vertex -180,-90*cos(-180.radians)
  -180.step(180,30){|x|
    curve_vertex x,-90*cos(x.radians)
  }
  curve_vertex 180,-90*cos(180.radians)
  end_shape
end
